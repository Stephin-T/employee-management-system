import React from 'react'
import { Link } from 'react-router-dom'

export default function Navbar() {
    return (
        <div>

            <nav className="navbar navbar-expand-lg navbar-dark bg-info">
                <div className="container-fluid">
                    <Link to={"/"} className="navbar-brand" href="#">User Management System</Link>

                    <Link to="/addUser" className='btn btn-outline-light'>Add User</Link>
                </div>
            </nav>


        </div>
    )
}
