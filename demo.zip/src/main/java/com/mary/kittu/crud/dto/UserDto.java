package com.mary.kittu.crud.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
    private Long id;

    //firstname should not be null or empty
    @NotEmpty(message = "First name cannot by null or empty.")
    private String firstName;
    //lastname  should not be null or empty
    @NotEmpty(message = "Last name cannot by null or empty.")
    private String lastName;

    //email  should not be null or empty and should be a valid email
    @NotEmpty(message = "Email cannot by null or empty.")
    @Email(message = "Enter a valid email address.")
    private String email;
}
