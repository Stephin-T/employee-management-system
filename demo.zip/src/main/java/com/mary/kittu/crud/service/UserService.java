package com.mary.kittu.crud.service;

import com.mary.kittu.crud.dto.UserDto;
import com.mary.kittu.crud.entity.User;

import java.util.List;

public interface UserService {
    UserDto createUser(UserDto user);

    UserDto getUserById(Long userId);

    List<UserDto> getAllUsers();
    UserDto updateUser(UserDto user);

    void deleteUser(Long userId);
}
