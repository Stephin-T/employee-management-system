package com.mary.kittu.crud.service.impl;

import com.mary.kittu.crud.dto.UserDto;
import com.mary.kittu.crud.entity.User;
import com.mary.kittu.crud.exception.EmailAlreadyExistsException;
import com.mary.kittu.crud.exception.ResourceNotFoundException;
import com.mary.kittu.crud.mapper.AutoUserMapper;
import com.mary.kittu.crud.mapper.UserMapper;
import com.mary.kittu.crud.repository.UserRepository;
import com.mary.kittu.crud.service.UserService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private ModelMapper modelMapper;

    @Override
    public UserDto createUser(UserDto userDto) {

        //Convert UserDto into User JPA entity
//        User user = UserMapper.mapToUser(userDto);

//        User user = modelMapper.map(userDto,User.class);
        Optional<User> optionalUserEmail = userRepository.findByEmail(userDto.getEmail());

        if(optionalUserEmail.isPresent()){

               throw new EmailAlreadyExistsException("Email already exists!");

        }

        User user = AutoUserMapper.MAPPER.mapToUser(userDto);


        User savedUser = userRepository.save(user);

        //Convert UserJPA entity to UserDto
//        UserDto savedUserDto = UserMapper.mapToUserDto(savedUser);

//        UserDto savedUserDto = modelMapper.map(savedUser,UserDto.class);

        UserDto savedUserDto = AutoUserMapper.MAPPER.mapToUserDto(savedUser);
        return savedUserDto;
    }

    @Override
    public UserDto getUserById(Long userId) {
       User user = userRepository.findById(userId).orElseThrow(
               () -> new ResourceNotFoundException("User","id",userId)
       );


//        UserDto userDto = UserMapper.mapToUserDto(user);
//        UserDto userDto = modelMapper.map(user, UserDto.class);

        UserDto userDto = AutoUserMapper.MAPPER.mapToUserDto(user);

        return userDto;

    }


    public List<UserDto> getAllUsers() {

        List<User> users = userRepository.findAll();

//        return users.stream().map(UserMapper::mapToUserDto).collect(Collectors.toList());
//        return users.stream().map(user -> modelMapper.map(user,UserDto.class)).collect(Collectors.toList());

        return users.stream().map(user -> AutoUserMapper.MAPPER.mapToUserDto(user)).collect(Collectors.toList());
    }




    public UserDto updateUser(UserDto user) {
        User existingUser = userRepository.findById(user.getId()).orElseThrow(
                () -> new ResourceNotFoundException("User","id", user.getId())
        );
        existingUser.setFirstName(user.getFirstName());
        existingUser.setLastName(user.getLastName());
        existingUser.setEmail(user.getEmail());

        User updatedUser = userRepository.save(existingUser);


//        return UserMapper.mapToUserDto(updatedUser);
//        return modelMapper.map(updatedUser, UserDto.class);

        return AutoUserMapper.MAPPER.mapToUserDto(updatedUser);
    }

    @Override
    public void deleteUser(Long userId) {

        User existingUser = userRepository.findById(userId).orElseThrow(
                () -> new ResourceNotFoundException("User","id", userId)
        );

        userRepository.deleteById(userId);
    }
}
