package com.mary.kittu.crud.mapper;

import com.mary.kittu.crud.dto.UserDto;
import com.mary.kittu.crud.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AutoUserMapper {

//    @Mapping(source = "email", target = "emailAddress") if field names are different.

    AutoUserMapper MAPPER  = Mappers.getMapper(AutoUserMapper.class); //This will provide the implementation for this interface at the compilation time.
                //And we can use this MAPPER instance to call the below mapping methods.
    UserDto mapToUserDto(User user);
    User mapToUser(UserDto userDto);

    //MapStruct will create the implementation for this automatically , We don't need to write any extra codes.
}
