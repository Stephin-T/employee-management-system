package com.stephin.mary.fullstackapp.repository;

import com.stephin.mary.fullstackapp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {

}
