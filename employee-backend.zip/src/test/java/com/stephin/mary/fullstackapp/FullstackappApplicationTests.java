package com.stephin.mary.fullstackapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackappApplicationTests {

	@Test
	void contextLoads() {
	}

}
